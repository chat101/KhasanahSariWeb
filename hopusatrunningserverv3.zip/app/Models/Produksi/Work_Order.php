<?php

namespace App\Models\Produksi;

use Illuminate\Database\Eloquent\Model;

class Work_Order extends Model
{
    //
}
