<?php

namespace App\Livewire\Finance;

use Livewire\Component;

class MasterRekening extends Component
{
    public function render()
    {
        return view('livewire.finance.master-rekening');
    }
}
