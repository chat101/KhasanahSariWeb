<?php

namespace App\Livewire\Finance;

use Livewire\Component;

class UangMasukPeriode extends Component
{
    public function render()
    {
        return view('livewire.finance.uang-masuk-periode');
    }
}
