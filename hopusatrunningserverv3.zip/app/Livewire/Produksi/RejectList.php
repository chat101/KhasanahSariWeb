<?php

namespace App\Livewire\Produksi;

use Livewire\Component;

class RejectList extends Component
{



    public function render()
    {
        return view('livewire.produksi.reject-list');
    }
}
