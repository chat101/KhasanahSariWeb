<?php

namespace App\Livewire\Produksi;

use Livewire\Component;

class JadwalDivisi extends Component
{
    public function render()
    {
        return view('livewire.produksi.jadwal-divisi');
    }
}
