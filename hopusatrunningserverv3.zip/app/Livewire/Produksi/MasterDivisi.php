<?php

namespace App\Livewire\Produksi;

use Livewire\Component;

class MasterDivisi extends Component
{
    public function render()
    {
        return view('livewire.produksi.master-divisi');
    }
}
