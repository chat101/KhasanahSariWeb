<?php

namespace App\Livewire\Produksi;

use Livewire\Component;

class HasilDivisi extends Component
{
    public function render()
    {
        return view('livewire.produksi.hasil-divisi');
    }
}
