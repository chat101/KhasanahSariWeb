<?php

namespace App\Livewire\Produksi;

use Livewire\Component;

class OpnamePenyesuaian extends Component
{

    public function render()
    {

        return view('livewire.produksi.opname-penyesuaian');
    }

}
