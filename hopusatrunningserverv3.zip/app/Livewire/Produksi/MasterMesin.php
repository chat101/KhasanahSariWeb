<?php

namespace App\Livewire\Produksi;

use Livewire\Component;

class MasterMesin extends Component
{
    public function render()
    {
        return view('livewire.produksi.master-mesin');
    }
}
