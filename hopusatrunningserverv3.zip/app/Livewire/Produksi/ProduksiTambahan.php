<?php

namespace App\Livewire\Produksi;

use Livewire\Component;

class ProduksiTambahan extends Component
{
    public function render()
    {
        return view('livewire.produksi.produksi-tambahan');
    }
}
