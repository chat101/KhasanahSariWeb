<?php return array (
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
    'App\\Events\\PerintahProduksiCreated' => 
    array (
      0 => 'App\\Listeners\\SendPerintahProduksiPush@handle',
    ),
  ),
);